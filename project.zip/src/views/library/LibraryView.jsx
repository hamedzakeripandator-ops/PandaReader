import React, { useState, useMemo, useCallback, useRef, useEffect } from 'react';
import useLibraryStore, {
  resolveHeroSliderItems,
  useCardReorderGrid,
  applyReorderToFullList,
} from '../../store/useLibraryStore';
import useAppStore from '../../store/useAppStore';
import ComicCard, { shouldSuppressCardClick } from './ComicCard';
import KineticHeroSlider from './KineticHeroSlider';
import { coreApi } from '../../services/coreApi';
import Icons from '../../components/common/Icons';
import { normalizeSearchTextLoose, fuzzyScoreLibraryItem } from '../../utils/persianSearch';

const FOLDER_COLORS = [
  '#22d3ee',
  '#f72585',
  '#a78bfa',
  '#4ade80',
  '#facc15',
  '#fb923c',
];

// مرحله ۴ — کارتِ تنبلِ کتابخانه: تا وقتی کارت (با حاشیهٔ امنِ ۴۰۰ پیکسل)
// واردِ دید نشده، فقط یک اسکلتِ سبک با همان ساختارِ کارت رندر می‌شود و
// هیچ getThumbnail صدا زده نمی‌شود. با خروج از دید، کارت آنمانت می‌شود و
// پاک‌سازیِ ComicCard درخواستِ در صفِ آن را لغو می‌کند (مراجعه:
// thumbnailService.js، مرحله ۴). مانتِ دوباره ارزان است چون کاور از کشِ
// رم/دیسک برمی‌گردد، نه از استخراجِ دوباره.
// مرحله ۴ ـ بخش ب: ارتفاعِ واقعیِ کارت، هنگامِ مرئی بودن اندازه‌گیری
// و روی اسکلت قفل می‌شود تا جایگزینیِ کارت با اسکلت، حتی یک پیکسل هم
// ارتفاعِ ردیف را عوض نکند و پرشِ اسکرول صفر شود (اسکلتِ ثابت، چون
// بخشِ توضیحاتِ کارت همیشه ۳۷ پیکسل عنوان + ردیفِ برچسب است، هرگز
// دقیق درنمی‌آمد).
// مرحله ۴۸ ـ اصلاحِ تلهٔ اسکلت: دیده‌شدن فقط یک‌طرفه است (latch).
// پیش از این، هر اعلانِ IntersectionObserver — حتی یک false گذرا
// هنگامِ جابه‌جاییِ گره‌های DOM در مرتب‌سازیِ دوباره پس از پین/آنپین —
// بی‌قیدوشرط isVisible را عوض می‌کرد و کارتِ از قبل رندرشده را پشتِ
// اسکلت پنهان می‌کرد (عنوان، بجِ فرمت، شمارهٔ صفحه و دکمه‌های پین/علاقه
// و برچسبِ پوشه همه با هم ناپدید می‌شدند). حالا false نادیده گرفته
// می‌شود و کارتی که یک‌بار دیده شده، در seenCardPaths می‌ماند: مانتِ
// دوبارهٔ همان مسیر، بی‌درنگ و بدونِ حتی یک فریم اسکلت، کارت را
// برمی‌گرداند. اسکلت فقط برای کارتی می‌ماند که واقعاً هرگز دیده نشده
// و بیرون از دید است؛ تنبلیِ بارگذاری (lazy) برای کارت‌هایِ ندیده
// دقیقاً مثلِ قبل حفظ می‌شود.
const seenCardPaths = new Set();
const SEEN_CARD_PATHS_MAX = 2000;

function normalizeSeenPath(filePath) {
  if (!filePath || typeof filePath !== 'string') return '';
  return filePath.trim().replace(/[\\/]+/g, '\\').toLowerCase();
}

function markCardPathSeen(key) {
  if (!key) return;
  if (seenCardPaths.has(key)) return;
  seenCardPaths.add(key);
  while (seenCardPaths.size > SEEN_CARD_PATHS_MAX) {
    const oldest = seenCardPaths.keys().next().value;
    if (oldest === undefined) break;
    seenCardPaths.delete(oldest);
  }
}

function LazyLibraryCard({ item, onOpenComic, onRemove, reorderable = false, onReorderActivate = null }) {
  const slotRef = useRef(null);
  const measuredHeightRef = useRef(0);
  const pathKey = normalizeSeenPath(item?.path || item?.filePath);
  // مرحله ۴۸: کارتِ یک‌بار دیده‌شده از همان رندرِ اول مرئی است؛
  // کارتِ هرگز ندیده با اسکلت شروع می‌کند تا تنبلی حفظ شود.
  const [isVisible, setIsVisible] = useState(
    () => !pathKey || seenCardPaths.has(pathKey)
  );

  useEffect(() => {
    const el = slotRef.current;
    if (!el || typeof IntersectionObserver === 'undefined') {
      if (pathKey) markCardPathSeen(pathKey);
      setIsVisible(true);
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        // مرحله ۴۸: فقط true پذیرفته می‌شود. false گذرا (مثلاً هنگامِ
        // جابه‌جاییِ گره در مرتب‌سازیِ دوباره پس از پین) هرگز کارتِ
        // دیده‌شده را پشتِ اسکلت نمی‌برد.
        if (entry && entry.isIntersecting) {
          if (pathKey) markCardPathSeen(pathKey);
          setIsVisible(true);
        }
      },
      { root: null, rootMargin: '400px 0px', threshold: 0 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [pathKey]);

  // مرحله ۴ ـ بخش ب: قفلِ ارتفاعِ اسکلت. تا وقتی کارت مرئی است،
  // ارتفاعِ واقعیِ slot خوانده و در ref نگه داشته می‌شود (ResizeObserver
  // تغییرِ ارتفاع بر اثرِ ری‌سایزِ پنجره یا تغییرِ محتوا را هم دنبال
  // می‌کند)؛ وقتی کارت از دید خارج شد و اسکلت جایش را گرفت، همان
  // ارتفاعِ اندازه‌گیری‌شده روی اسکلت اعمال می‌شود. ref عمداً state
  // نیست: خواندنش دقیقاً در همان رندرِ تعویض انجام می‌شود.
  useEffect(() => {
    if (!isVisible) return;
    const el = slotRef.current;
    if (!el) return;
    const measure = () => {
      const h = el.offsetHeight || 0;
      if (h > 0) measuredHeightRef.current = h;
    };
    measure();
    if (typeof ResizeObserver !== 'undefined') {
      const ro = new ResizeObserver(measure);
      ro.observe(el);
      return () => ro.disconnect();
    }
    window.addEventListener('resize', measure);
    return () => window.removeEventListener('resize', measure);
  }, [isVisible]);

  const lockedHeight = measuredHeightRef.current;

  // مرحله ۴۸: با latch بالا، این شاخهٔ اسکلت فقط برای کارتی می‌رسد که
  // واقعاً هرگز دیده نشده و بیرون از دید است؛ کارتِ دیده‌شده هرگز
  // دوباره اسکلت نمی‌شود.
  return (
    // مرحلهٔ ۵۳ — مأموریت ۳: data-cr-card-slot، شناسهٔ اندازه‌گیریِ
    // کارت در گرید است (مسیرِ نرمال‌شده) و cr-repel-card، گرهی است
    // که دافعهٔ مغناطیسی مستقیم رویِ آن اعمال می‌شود.
    <div ref={slotRef} data-cr-card-slot={pathKey} className="cr-repel-card">
      {isVisible ? (
        <ComicCard
          item={item}
          onOpenComic={onOpenComic}
          onRemove={onRemove}
          reorderable={reorderable}
          onReorderActivate={onReorderActivate}
        />
      ) : (
        <div
          style={
            lockedHeight > 0
              ? {
                  ...styles.cardSkeleton,
                  height: lockedHeight,
                  boxSizing: 'border-box',
                  overflow: 'hidden',
                }
              : styles.cardSkeleton
          }
        >
          <div style={styles.skeletonCover} />
          <div style={styles.skeletonLine} />
          <div style={{ ...styles.skeletonLine, width: '60%' }} />
        </div>
      )}
    </div>
  );
}

export default function LibraryView({ onOpenComic }) {
  const library = useLibraryStore((state) => state.library);
  const libraryItems = useLibraryStore((state) => state.libraryItems);
  const libraryFolders = useLibraryStore((state) => state.libraryFolders || []);
  const activeFolderId = useLibraryStore((state) => state.activeFolderId || 'ALL');
  const setActiveFolder = useLibraryStore((state) => state.setActiveFolder);
  const createFolder = useLibraryStore((state) => state.createFolder);
  const renameFolder = useLibraryStore((state) => state.renameFolder);
  const deleteFolder = useLibraryStore((state) => state.deleteFolder);
  const assignToFolder = useLibraryStore((state) => state.assignToFolder);

  const recentItems = useLibraryStore((state) => state.recentItems);
  const favorites = useLibraryStore((state) => state.favorites);
  // مرحلهٔ ۵۰ §۵ — منبعِ اسلایدرِ هیرو.
  const heroSliderSource = useLibraryStore((state) => state.heroSliderSource || 'auto');
  const heroSliderFolderId = useLibraryStore((state) => state.heroSliderFolderId || null);
  const customSliderBookPaths = useLibraryStore((state) => state.customSliderBookPaths || []);
  const addToLibrary = useLibraryStore((state) => state.addToLibrary);
  const removeFromLibrary = useLibraryStore((state) => state.removeFromLibrary);
  const reorderLibraryItems = useLibraryStore((state) => state.reorderLibraryItems);

  const searchQuery = useAppStore((state) => state.searchQuery);
  const showToast = useAppStore((state) => state.showToast);

  const effectiveLibrary = useMemo(
    () => library || libraryItems || [],
    [library, libraryItems]
  );

  const [filterMode, setFilterMode] = useState('all');
  // مرحلهٔ ۵۳ — مأموریت ۳: «چیدمان دستی (سفارشی)» گزینهٔ تازهٔ
  // مرتب‌سازی است و انتخابِ آن در localStorage می‌ماند تا چیدمانِ
  // دستی پس از ری‌استارت هم حفظ شود. مقدارِ ناشناختهٔ قدیمی،
  // به newest برمی‌گردد.
  const [sortBy, setSortBy] = useState(() => {
    try {
      const saved = localStorage.getItem('comicReader.librarySort.v1');
      if (
        saved === 'custom' ||
        saved === 'name' ||
        saved === 'progress' ||
        saved === 'newest'
      ) {
        return saved;
      }
    } catch (_) {}
    return 'newest';
  });

  const handleSortChange = (value) => {
    const next =
      value === 'custom' || value === 'name' || value === 'progress'
        ? value
        : 'newest';
    setSortBy(next);
    try {
      localStorage.setItem('comicReader.librarySort.v1', next);
    } catch (_) {}
  };

  // استیت‌های مودال ساخت / ویرایش پوشه در کتابخانه
  const [folderModal, setFolderModal] = useState(null); // { mode: 'create'|'edit', id, name, color }
  const [dragOverFolderId, setDragOverFolderId] = useState(null);

  // ۱. آیتم‌های اسلایدر Kinetic — مرحلهٔ ۵۰ §۵: بر اساسِ منبعِ
  // انتخاب‌شده حل می‌شود (resolveHeroSliderItems در استور؛ همان
  // منطقی که تست‌ها می‌خوانند). حالتِ auto دقیقاً رفتارِ قبلی است
  // (پین‌شده‌ها، بعد اخیر، بعد کتابخانه — سقفِ ۷ در اسلایدر).
  // حالت‌هایِ پوشه و دستی هیچ سقفی ندارند: لیست دقیقاً به‌اندازهٔ
  // کتاب‌هایِ واقعیِ منبع است. مسیرِ کتابِ حذف‌شده کنار می‌رود و
  // هرگز اسلایدِ خالی نمی‌سازد.
  const sliderItems = useMemo(
    () =>
      resolveHeroSliderItems({
        source: heroSliderSource,
        folderId: heroSliderFolderId,
        customPaths: customSliderBookPaths,
        library: effectiveLibrary,
        recentItems,
        favorites,
      }),
    [effectiveLibrary, recentItems, favorites, heroSliderSource, heroSliderFolderId, customSliderBookPaths]
  );

  // ۲. محاسبه تعداد آیتم‌های هر پوشه
  const folderCounts = useMemo(() => {
    const counts = {
      ALL: effectiveLibrary.length,
      PINNED: 0,
      UNFOLDERED: 0,
    };
    libraryFolders.forEach((f) => {
      counts[f.id] = 0;
    });

    effectiveLibrary.forEach((item) => {
      if (item.isPinned) counts.PINNED++;
      if (item.folderId && counts[item.folderId] !== undefined) {
        counts[item.folderId]++;
      } else {
        counts.UNFOLDERED++;
      }
    });

    return counts;
  }, [effectiveLibrary, libraryFolders]);

  // نام پوشهٔ هر آیتم (فیلدِ دومِ جستجوی فازی)
  const folderNameById = useMemo(() => {
    const m = new Map();
    (libraryFolders || []).forEach((f) => {
      if (f?.id) m.set(f.id, f.name || '');
    });
    return m;
  }, [libraryFolders]);

  // ۳. فیلتر و مرتب‌سازی گرید کتابخانه (با حفظ اولویت ۱۰۰٪ آیتم‌های پین‌شده در صدر)
  const displayedLibrary = useMemo(() => {
    // مرحله ۴ — جستجوی فازی: به‌جای includes ساده، امتیاز چندفیلدی
    // (نام ×۳، پوشه ×۲، مسیر ×۱، تگ‌ها ×۲) با نرمال‌سازی فارسی
    // (ی/ي، ک/ك)، تطابق زیررشته/پیشوند، تحمل اشتباه تایپی و تطابق
    // حروف پراکنده. وقتی عبارتی نیست، رفتار دقیقاً مثل قبل است.
    const q = normalizeSearchTextLoose(searchQuery || '');

    const filtered = effectiveLibrary
      .map((item) => ({
        item,
        score: q
          ? fuzzyScoreLibraryItem(q, [
              { text: item.name || item.fileName || '', weight: 3 },
              { text: folderNameById.get(item.folderId) || '', weight: 2 },
              { text: item.path || item.filePath || '', weight: 1 },
              { text: (item.tags || []).join(' '), weight: 2 },
            ])
          : 0,
      }))
      .filter(({ item, score }) => {
        if (q && score <= 0) return false;
        // مرحله ۴۷ §۲: کارتِ بدونِ مسیرِ یکتا نه قابلِ باز شدن است و
        // نه قابلِ پین؛ رندرِ آن فقط کلیدِ تکراری و کارتِ اشتباه
        // می‌سازد، پس از گرید کنار گذاشته می‌شود.
        if (!item.path && !item.filePath) return false;
        const path = (item.path || item.filePath || '').toLowerCase();

      // فیلتر بر اساس پوشه انتخاب‌شده
      if (activeFolderId === 'PINNED' && !item.isPinned) return false;
      if (activeFolderId === 'UNFOLDERED' && item.folderId) return false;
      if (
        activeFolderId &&
        !['ALL', 'PINNED', 'UNFOLDERED'].includes(activeFolderId) &&
        item.folderId !== activeFolderId
      ) {
        return false;
      }

      // فیلتر بر اساس وضعیت علاقه‌مندی / در حال مطالعه
      if (filterMode === 'favorites') {
        const norm = path.replace(/[\\/]+/g, '\\').toLowerCase();
        return (favorites || []).some(
          (f) =>
            (f.path || f.filePath || '').toLowerCase().replace(/[\\/]+/g, '\\') === norm
        );
      }
      if (filterMode === 'reading') {
        const prog = item.percentage ?? item.progress ?? 0;
        return (item.lastPage && item.lastPage > 1) || prog > 0;
      }
      return true;
    });

    // مرحلهٔ ۵۳ — مأموریت ۳ (گاردِ باگِ ۴): در «چیدمان دستی»،
    // ترتیبِ استور (customOrder) بدونِ هیچ مرتب‌سازیِ دوباره
    // می‌ماند — پین‌اول هم در این حالت خاموش است، وگرنه کارتِ
    // عادی هرگز نمی‌توانست میانِ پین‌شده‌ها بنشیند. جستجو در این
    // حالت فقط فیلتر می‌کند و رتبه‌بندیِ فازی نمی‌کند.
    if (sortBy === 'custom') {
      return filtered.map(({ item }) => item);
    }

    return [...filtered]
      .sort((a, b) => {
        // آیتم‌های پین‌شده همیشه در بالای لیست قرار می‌گیرند
        const aPin = a.item?.isPinned ? 1 : 0;
        const bPin = b.item?.isPinned ? 1 : 0;
        if (aPin !== bPin) return bPin - aPin;

        // مرحله ۴ — وقتی عبارتی هست، رتبهٔ فازی بعد از پین می‌آید؛
        // در غیر این صورت، مرتب‌سازیِ قبلی دقیقاً حفظ می‌شود.
        if (q && b.score !== a.score) return b.score - a.score;

        if (sortBy === 'name') {
          return (a.item.name || '').localeCompare(b.item.name || '', 'fa');
        }
        if (sortBy === 'progress') {
          const pA = a.item.percentage ?? a.item.progress ?? 0;
          const pB = b.item.percentage ?? b.item.progress ?? 0;
          return pB - pA;
        }
        return new Date(b.item.addedAt || 0) - new Date(a.item.addedAt || 0);
      })
      .map(({ item }) => item);
  }, [effectiveLibrary, favorites, searchQuery, activeFolderId, filterMode, sortBy, folderNameById]);

  const handleAddNewToLibrary = async () => {
    const res = await coreApi.openFile();
    if (res?.success && res.filePath) {
      const targetFolder = !['ALL', 'PINNED', 'UNFOLDERED'].includes(activeFolderId)
        ? activeFolderId
        : null;
      await addToLibrary({
        path: res.filePath,
        name: res.fileName || res.filePath.split(/[\\/]/).pop(),
        cover: res.cover || null,
        fileSize: res.fileSize,
        folderId: targetFolder,
      });
      showToast('عنوان جدید با موفقیت به کتابخانه اضافه شد', { type: 'success' });
    }
  };

  const handleRemoveFromLib = useCallback(
    async (filePath, title) => {
      await removeFromLibrary(filePath);
      showToast(`«${title}» از کتابخانه حذف شد`, { type: 'info' });
    },
    [removeFromLibrary, showToast]
  );

  // ذخیره پوشه جدید یا ویرایش‌شده در دیتابیس
  const handleSaveFolderModal = async () => {
    if (!folderModal) return;
    const cleanName = (folderModal.name || '').trim();
    if (!cleanName) {
      showToast('لطفاً نام پوشه را وارد کنید', { type: 'warning' });
      return;
    }

    if (folderModal.mode === 'edit' && folderModal.id) {
      await renameFolder(folderModal.id, cleanName, folderModal.color);
      showToast(`پوشه «${cleanName}» ویرایش شد`, { type: 'success' });
    } else {
      const created = await createFolder(cleanName, folderModal.color);
      if (created?.id) {
        setActiveFolder(created.id);
      }
      showToast(`پوشه «${cleanName}» ساخته و در دیتابیس ذخیره شد`, { type: 'success' });
    }
    setFolderModal(null);
  };

  const handleDeleteActiveFolder = async (folder) => {
    if (!folder?.id) return;
    await deleteFolder(folder.id);
    showToast(`پوشه «${folder.name}» حذف شد`, { type: 'info' });
  };

  // مرحلهٔ ۵۴ — مأموریت ۱: انتقالِ کارت به پوشه با مسیرِ مشترک؛
  // هم رها کردنِ بومی (dataTransfer) و هم رها کردنِ اشاره‌گرِ
  // فوری (elementFromPoint) از همین‌جا می‌گذرند. 'ALL' و
  // 'UNFOLDERED' یعنی بیرون از پوشه (null).
  const assignCardToFolderId = useCallback(
    async (draggedPath, targetFolderId) => {
      if (!draggedPath) return;
      const realFolderId =
        targetFolderId === 'ALL' || targetFolderId === 'UNFOLDERED'
          ? null
          : targetFolderId;
      await assignToFolder(draggedPath, realFolderId);
      const targetFolderObj = libraryFolders.find((f) => f.id === realFolderId);
      showToast(
        targetFolderObj
          ? `به پوشه «${targetFolderObj.name}» منتقل شد`
          : 'به نمای کلی کتابخانه منتقل شد',
        { type: 'success' }
      );
    },
    [assignToFolder, libraryFolders, showToast]
  );

  // رها کردن کارت کشیده‌شده روی تب پوشه (Drag & Drop to Folder)
  const handleDropCardOnFolder = async (e, targetFolderId) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOverFolderId(null);

    const draggedPath = e.dataTransfer.getData('text/comic-path');
    if (!draggedPath) return;

    await assignCardToFolderId(draggedPath, targetFolderId);
  };

  // مرحلهٔ ۵۴ — مأموریت ۱: رها کردنِ اشاره‌گرِ فوری رویِ تبِ
  // پوشه؛ هوک، تبِ زیرِ نشانگر را با data-folder-drop-id پیدا
  // کرده و شناسه‌اش را اینجا می‌دهد. کلیکِ پس از درگ، با
  // wasReorderingRef بلعیده می‌شود و تب عوض نمی‌شود.
  const handlePointerFolderDrop = useCallback(
    (draggedPath, targetFolderId) => {
      setDragOverFolderId(null);
      assignCardToFolderId(draggedPath, targetFolderId);
    },
    [assignCardToFolderId]
  );

  // مرحلهٔ ۵۴ — مأموریت ۱: سیم‌کشیِ جابه‌جاییِ فوریِ کارت‌ها (بدونِ نگه‌داشتن).
  const gridRef = useRef(null);
  const scrollRef = useRef(null);

  const handleReorderCommit = useCallback(
    (visibleOrderedPaths) => {
      // ترتیبِ نمایِ فیلترشده، با حفظِ ۱۰۰٪ بقیه، در فهرستِ کامل
      // ادغام می‌شود (گاردِ باگِ ۲) و با customOrder ذخیره می‌شود؛
      // هم‌زمان، sort به «چیدمان دستی» می‌رود و می‌ماند.
      const fullOrdered = applyReorderToFullList(effectiveLibrary, visibleOrderedPaths);
      const fullPaths = fullOrdered
        .map((item) => item.path || item.filePath)
        .filter(Boolean);
      reorderLibraryItems(fullPaths);
      setSortBy('custom');
      try {
        localStorage.setItem('comicReader.librarySort.v1', 'custom');
      } catch (_) {}
    },
    [effectiveLibrary, reorderLibraryItems]
  );

  const reorder = useCardReorderGrid({
    enabled: true,
    visibleItems: displayedLibrary,
    gridRef,
    scrollRef,
    onCommit: handleReorderCommit,
    onFolderDrop: handlePointerFolderDrop,
  });

  // گاردِ باگِ ۱: رها کردنِ نشانگر پس از درگ، هرگز کتاب را باز
  // نمی‌کند؛ هوک، کلیکِ همان ژست را با wasReorderingRef می‌بلعد.
  const guardedOpenComic = useCallback(
    (item) => {
      if (reorder.wasReorderingRef.current) {
        reorder.wasReorderingRef.current = false;
        return;
      }
      // مرحلهٔ ۵۴ — مأموریت ۲ (m2) لایهٔ ۲: کلیکِ پس از هر درگِ داخلیِ
      // کارت (جابه‌جایی یا کشیدن به تبِ پوشه) هم بلعیده می‌شود؛ پرچم
      // تا ۱۰۰ میلی‌ثانیه پس از pointerup روشن می‌ماند، پس کلیکِ
      // همان ژست هنوز آن را روشن می‌بیند. رفتارِ مرحلهٔ ۵۳
      // (wasReorderingRef) دست‌نخورده می‌ماند.
      if (shouldSuppressCardClick()) return;
      if (onOpenComic) onOpenComic(item);
    },
    [onOpenComic]
  );

  // مرحلهٔ ۵۴ — مأموریت ۱: کلیکِ تبِ پوشه پس از رها کردنِ درگِ
  // فوری، نباید پوشهٔ فعال را عوض کند؛ همان گاردِ wasReorderingRef
  // که کلیکِ بازکنندهٔ کتاب را می‌بلعد، اینجا هم به کار می‌رود.
  const guardedSetActiveFolder = useCallback(
    (folderId) => {
      if (reorder.wasReorderingRef.current) {
        reorder.wasReorderingRef.current = false;
        return;
      }
      setActiveFolder(folderId);
    },
    [setActiveFolder]
  );

  // رندرِ گرید در حالتِ جابه‌جایی: کارتِ گرفته‌شده از گرید بیرون
  // می‌رود و جایِ خالیِ نقطه‌چین (اسلات) در جایِ هدف می‌نشیند؛
  // ارتفاعِ اسلات از ارتفاعِ اندازه‌گیری‌شدهٔ کارت می‌آید تا
  // ردیف‌هایِ گرید تکان نخورند. در حالتِ عادی، دقیقاً مثلِ قبل.
  const renderGridCards = () => {
    const isDragging = Boolean(reorder.grabbedPath);
    const list = isDragging ? reorder.previewItems : displayedLibrary;
    const nodes = [];
    list.forEach((item, idx) => {
      if (isDragging && reorder.placeholderIndex === idx) {
        nodes.push(
          <div
            key="cr-reorder-slot"
            className="cr-reorder-slot"
            style={{
              height: reorder.floatingRect ? reorder.floatingRect.height : undefined,
            }}
          />
        );
      }
      nodes.push(
        <LazyLibraryCard
          key={item.path || item.filePath}
          item={item}
          onOpenComic={guardedOpenComic}
          onRemove={handleRemoveFromLib}
          reorderable={!isDragging}
          onReorderActivate={reorder.onReorderActivate}
        />
      );
    });
    if (isDragging && reorder.placeholderIndex >= list.length) {
      nodes.push(
        <div
          key="cr-reorder-slot"
          className="cr-reorder-slot"
          style={{
            height: reorder.floatingRect ? reorder.floatingRect.height : undefined,
          }}
        />
      );
    }
    return nodes;
  };

  const activeFolderObject = useMemo(
    () => libraryFolders.find((f) => f.id === activeFolderId) || null,
    [libraryFolders, activeFolderId]
  );

  return (
    <div ref={scrollRef} style={styles.container}>
      <div style={styles.containerInner}>
      {/* =====================================================================
          ۱. اسلایدر Kinetic Typography + Split Navigation
      ===================================================================== */}
      {/* مرحلهٔ ۵۰ §۵: در حالت‌هایِ دستی/پوشه، اسلایدر حتی وقتی
          خالی است رندر می‌شود تا بنرِ راهنما و منویِ منبع دیده شوند؛
          capSlides فقط در حالتِ خودکار، سقفِ ۷تاییِ قبلی را نگه می‌دارد. */}
      {(sliderItems.length > 0 || heroSliderSource !== 'auto') && (
        <KineticHeroSlider
          items={sliderItems}
          onOpenComic={onOpenComic}
          capSlides={heroSliderSource === 'auto'}
        />
      )}

      {/* =====================================================================
          ۲. بخش آرشیو، نوار پوشه‌بندی و گرید کارت‌های کتابخانه
      ===================================================================== */}
      <section style={styles.gridSection}>
        {/* هدر اصلی کتابخانه */}
        <div style={styles.toolbarHeader}>
          <div style={styles.headerTitleBox}>
            <span style={{ color: 'var(--accent)', display: 'flex' }}>
              <Icons.Library size={21} />
            </span>
            <h3 style={styles.sectionTitle}>آرشیو مانهوا، کمیک و کتابخانه</h3>
            <span style={styles.countBadge}>{displayedLibrary.length} عنوان</span>
          </div>

          <div style={styles.controlsGroup}>
            <div style={styles.filterPills}>
              {[
                { id: 'all', label: 'همه عناوین' },
                { id: 'favorites', label: 'مورد علاقه‌ها' },
                { id: 'reading', label: 'در حال مطالعه' },
              ].map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setFilterMode(f.id)}
                  style={{
                    ...styles.filterBtn,
                    ...(filterMode === f.id ? styles.filterBtnActive : {}),
                  }}
                >
                  {f.label}
                </button>
              ))}
            </div>

            <select
              value={sortBy}
              onChange={(e) => handleSortChange(e.target.value)}
              style={styles.sortSelect}
            >
              <option value="newest">مرتب‌سازی: جدیدترین (پین‌ها در صدر)</option>
              <option value="name">مرتب‌سازی: نام الفبا (پین‌ها در صدر)</option>
              <option value="progress">مرتب‌سازی: بیشترین پیشرفت</option>
              <option value="custom">مرتب‌سازی: چیدمان دستی (سفارشی)</option>
            </select>

            <button
              type="button"
              onClick={handleAddNewToLibrary}
              style={styles.addComicBtn}
            >
              <Icons.Plus size={14} />
              <span>افزودن فایل به کتابخانه</span>
            </button>
          </div>
        </div>

        {/* =================================================================
            نوار پوشه‌بندی کتابخانه (Library Folders Bar) متصل به دیتابیس
        ================================================================= */}
        <div style={styles.foldersBarWrap}>
          <div style={styles.foldersScrollRow}>
            {/* تب همه عناوین */}
            <button
              type="button"
              data-folder-drop-id="ALL"
              onClick={() => guardedSetActiveFolder('ALL')}
              onDragOver={(e) => {
                e.preventDefault();
                setDragOverFolderId('ALL');
              }}
              onDragLeave={() => setDragOverFolderId(null)}
              onDrop={(e) => handleDropCardOnFolder(e, 'ALL')}
              style={{
                ...styles.folderTabBtn,
                backgroundColor:
                  activeFolderId === 'ALL'
                    ? 'rgba(34, 211, 238, 0.16)'
                    : 'var(--panel2)',
                borderColor:
                  reorder.folderDropTargetId === 'ALL' ||
                  dragOverFolderId === 'ALL'
                    ? '#f72585'
                    : activeFolderId === 'ALL'
                    ? 'var(--accent)'
                    : 'var(--border)',
                color: activeFolderId === 'ALL' ? 'var(--accent)' : 'var(--text)',
              }}
            >
              <Icons.Layers size={14} />
              <span>همه کتاب‌ها</span>
              <span style={styles.folderTabCount}>{folderCounts.ALL}</span>
            </button>

            {/* تب پین‌شده‌ها */}
            <button
              type="button"
              onClick={() => guardedSetActiveFolder('PINNED')}
              style={{
                ...styles.folderTabBtn,
                backgroundColor:
                  activeFolderId === 'PINNED'
                    ? 'rgba(34, 211, 238, 0.16)'
                    : 'var(--panel2)',
                borderColor:
                  activeFolderId === 'PINNED' ? 'var(--accent)' : 'var(--border)',
                color: activeFolderId === 'PINNED' ? 'var(--accent)' : 'var(--text)',
              }}
            >
              <Icons.Pin size={14} filled={activeFolderId === 'PINNED'} />
              <span>پین‌شده‌ها</span>
              <span style={styles.folderTabCount}>{folderCounts.PINNED}</span>
            </button>

            {/* تب بدون پوشه */}
            <button
              type="button"
              data-folder-drop-id="UNFOLDERED"
              onClick={() => guardedSetActiveFolder('UNFOLDERED')}
              onDragOver={(e) => {
                e.preventDefault();
                setDragOverFolderId('UNFOLDERED');
              }}
              onDragLeave={() => setDragOverFolderId(null)}
              onDrop={(e) => handleDropCardOnFolder(e, 'UNFOLDERED')}
              style={{
                ...styles.folderTabBtn,
                backgroundColor:
                  activeFolderId === 'UNFOLDERED'
                    ? 'rgba(34, 211, 238, 0.16)'
                    : 'var(--panel2)',
                borderColor:
                  reorder.folderDropTargetId === 'UNFOLDERED' ||
                  dragOverFolderId === 'UNFOLDERED'
                    ? '#f72585'
                    : activeFolderId === 'UNFOLDERED'
                    ? 'var(--accent)'
                    : 'var(--border)',
                color:
                  activeFolderId === 'UNFOLDERED' ? 'var(--accent)' : 'var(--muted)',
              }}
            >
              <Icons.Folder size={14} />
              <span>بدون پوشه</span>
              <span style={styles.folderTabCount}>{folderCounts.UNFOLDERED}</span>
            </button>

            {/* تب پوشه‌های سفارشی کاربر */}
            {libraryFolders.map((folder) => {
              const isSelected = activeFolderId === folder.id;
              const isDragTarget =
                reorder.folderDropTargetId === folder.id ||
                dragOverFolderId === folder.id;
              const fColor = folder.color || '#22d3ee';

              return (
                <button
                  key={folder.id}
                  type="button"
                  data-folder-drop-id={folder.id}
                  onClick={() => guardedSetActiveFolder(folder.id)}
                  onDragOver={(e) => {
                    e.preventDefault();
                    setDragOverFolderId(folder.id);
                  }}
                  onDragLeave={() => setDragOverFolderId(null)}
                  onDrop={(e) => handleDropCardOnFolder(e, folder.id)}
                  style={{
                    ...styles.folderTabBtn,
                    backgroundColor: isSelected
                      ? 'rgba(255, 255, 255, 0.08)'
                      : 'var(--panel2)',
                    borderColor: isDragTarget
                      ? '#f72585'
                      : isSelected
                      ? fColor
                      : 'var(--border)',
                    color: isSelected ? '#ffffff' : 'var(--text)',
                    transform: isDragTarget ? 'scale(1.05)' : 'scale(1)',
                  }}
                  title="کلیک برای مشاهده پوشه (یا کارت کمیک را بکشید و اینجا رها کنید)"
                >
                  <span
                    style={{
                      width: '9px',
                      height: '9px',
                      borderRadius: '50%',
                      backgroundColor: fColor,
                      boxShadow: isSelected ? `0 0 8px ${fColor}` : 'none',
                    }}
                  />
                  <span>{folder.name}</span>
                  <span style={styles.folderTabCount}>
                    {folderCounts[folder.id] || 0}
                  </span>
                </button>
              );
            })}

            {/* دکمه ساخت پوشه جدید */}
            <button
              type="button"
              onClick={() =>
                setFolderModal({
                  mode: 'create',
                  id: null,
                  name: '',
                  color: '#22d3ee',
                })
              }
              style={styles.newFolderBtn}
              title="ساخت پوشه جدید در کتابخانه"
            >
              <Icons.FolderPlus size={14} />
              <span>+ پوشه جدید</span>
            </button>
          </div>

          {/* نوار مدیریت پوشه فعال (ویرایش نام / حذف پوشه) */}
          {activeFolderObject && (
            <div style={styles.activeFolderActionsBar}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Icons.Folder
                  size={15}
                  filled
                  fillColor={activeFolderObject.color || '#22d3ee'}
                />
                <span style={styles.activeFolderTitle}>
                  پوشه فعال: <strong>{activeFolderObject.name}</strong>
                </span>
                <span style={styles.dragToFolderHint}>
                  (می‌توانید کارت‌ها را روی پوشه‌های بالا بکشید و رها کنید)
                </span>
              </div>

              <div style={{ display: 'flex', gap: '8px' }}>
                <button
                  type="button"
                  onClick={() =>
                    setFolderModal({
                      mode: 'edit',
                      id: activeFolderObject.id,
                      name: activeFolderObject.name,
                      color: activeFolderObject.color || '#22d3ee',
                    })
                  }
                  style={styles.folderManageBtn}
                >
                  <Icons.Edit3 size={13} />
                  <span>ویرایش پوشه</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleDeleteActiveFolder(activeFolderObject)}
                  style={{ ...styles.folderManageBtn, color: 'var(--danger)' }}
                >
                  <Icons.Trash size={13} />
                  <span>حذف پوشه</span>
                </button>
              </div>
            </div>
          )}

          {/* فرم بازشوی ساخت / ویرایش پوشه */}
          {folderModal && (
            <div style={styles.folderEditorCard}>
              <div style={styles.folderEditorRow}>
                <Icons.FolderPlus size={16} />
                <input
                  type="text"
                  autoFocus
                  value={folderModal.name}
                  onChange={(e) =>
                    setFolderModal((prev) => ({ ...prev, name: e.target.value }))
                  }
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSaveFolderModal();
                    if (e.key === 'Escape') setFolderModal(null);
                  }}
                  placeholder="نام پوشه (مثلاً: آناتومی، فیزیولوژی، مانهواهای اکشن)..."
                  style={styles.folderNameInput}
                />

                <div style={styles.folderColorPicker}>
                  {FOLDER_COLORS.map((col) => (
                    <button
                      key={col}
                      type="button"
                      onClick={() =>
                        setFolderModal((prev) => ({ ...prev, color: col }))
                      }
                      style={{
                        ...styles.folderColorDot,
                        backgroundColor: col,
                        transform:
                          folderModal.color === col ? 'scale(1.25)' : 'scale(1)',
                        borderColor:
                          folderModal.color === col ? '#ffffff' : 'transparent',
                      }}
                    />
                  ))}
                </div>

                <button
                  type="button"
                  onClick={handleSaveFolderModal}
                  style={styles.folderSaveBtn}
                >
                  {folderModal.mode === 'edit' ? 'ذخیره تغییرات' : 'ساخت پوشه'}
                </button>
                <button
                  type="button"
                  onClick={() => setFolderModal(null)}
                  style={styles.folderCancelBtn}
                >
                  انصراف
                </button>
              </div>
            </div>
          )}
        </div>

        {/* گرید کارت‌های کتابخانه */}
        {displayedLibrary.length === 0 ? (
          <div style={styles.emptyBox}>
            <div style={{ color: 'var(--muted)', marginBottom: '8px' }}>
              <Icons.FolderOpen size={40} />
            </div>
            <p style={styles.emptyText}>
              {searchQuery
                ? `هیچ عنوانی با عبارت «${searchQuery}» در این بخش یافت نشد.`
                : activeFolderObject
                ? `پوشه «${activeFolderObject.name}» خالی است. با دکمه پوشه روی کارت‌ها یا کشیدن کارت‌ها، کتاب‌ها را به این پوشه اضافه کنید.`
                : activeFolderId === 'PINNED'
                ? 'هنوز هیچ کتابی را پین نکرده‌اید. با زدن آیکون پین روی کارت‌ها، آن‌ها را در صدر کتابخانه ثابت کنید.'
                : 'کتابخانه شما خالی است. با دکمه «+ افزودن فایل به کتابخانه» اولین عنوان را اضافه کنید.'}
            </p>
          </div>
        ) : (
          <div ref={gridRef} style={styles.cardsGrid}>
            {renderGridCards()}
          </div>
        )}
      </section>
      {/* مرحلهٔ ۵۴ — مأموریت ۱: کارتِ شناورِ گرفته‌شده که دنبالِ
          نشانگر می‌آید؛ موقعیتِ آن ثابت نسبت به پنجره است و
          جابه‌جایی‌اش فقط با translate3d در هوک عوض می‌شود.
          reorderable در اینجا false است، چون کارت همین حالا
          گرفته شده و درگِ تازه نمی‌خواهد. */}
      {reorder.floatingItem && (
        <div
          ref={reorder.floatingElRef}
          className="cr-reorder-floating"
          style={{
            left: reorder.floatingRect.left,
            top: reorder.floatingRect.top,
            width: reorder.floatingRect.width,
          }}
        >
          <ComicCard
            item={reorder.floatingItem}
            onOpenComic={guardedOpenComic}
            onRemove={handleRemoveFromLib}
            reorderable={false}
            isGrabbedForReorder
          />
        </div>
      )}
      </div>
    </div>
  );
}

const styles = {
  container: {
    flex: 1,
    padding: '14px 18px 28px',
    display: 'flex',
    flexDirection: 'column',
    gap: '20px',
    overflowY: 'auto',
    direction: 'ltr',
    userSelect: 'none',
  },  // مرحله ۱۲: محتوای درونیِ اسکرول‌خور — جهتِ راست‌به‌چپِ
  // فارسی، دقیقاً با همان فاصله‌ها (gap) حفظ می‌شود؛ فقط
  // خودِ کانتینرِ اسکرول‌خور، چپ‌به‌راست است تا کرومیوم،
  // نوارِ اسکرول را در لبهٔ سمتِ راست رندر کند.
  containerInner: {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px',
    direction: 'rtl',
    flex: 1,
    minWidth: 0,
  },

  gridSection: {
    display: 'flex',
    flexDirection: 'column',
    gap: '14px',
    backgroundColor: 'var(--panel)',
    borderRadius: '20px',
    borderWidth: '1px',
    borderStyle: 'solid',
    borderColor: 'var(--border)',
    padding: '18px 20px',
  },
  toolbarHeader: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
    gap: '12px',
    paddingBottom: '12px',
    borderBottomWidth: '1px',
    borderBottomStyle: 'solid',
    borderBottomColor: 'var(--border)',
  },
  headerTitleBox: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
  },
  sectionTitle: {
    fontFamily: 'var(--font-fa)',
    fontSize: '19px',
    fontWeight: 800,
    margin: 0,
    color: 'var(--text)',
  },
  countBadge: {
    fontFamily: 'var(--font-fa)',
    fontSize: '11px',
    fontWeight: 600,
    color: 'var(--accent)',
    backgroundColor: 'rgba(34, 211, 238, 0.12)',
    padding: '3px 10px',
    borderRadius: '10px',
    fontVariantNumeric: 'tabular-nums',
  },
  controlsGroup: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
    flexWrap: 'wrap',
  },
  filterPills: {
    display: 'flex',
    gap: '6px',
    backgroundColor: 'var(--panel2)',
    padding: '4px',
    borderRadius: '12px',
    borderWidth: '1px',
    borderStyle: 'solid',
    borderColor: 'var(--border)',
  },
  filterBtn: {
    padding: '6px 12px',
    borderRadius: '9px',
    border: 'none',
    backgroundColor: 'transparent',
    color: 'var(--muted)',
    fontFamily: 'var(--font-fa)',
    fontSize: '12.5px',
    fontWeight: 500,
    cursor: 'pointer',
    transition: 'all 0.15s ease',
  },
  filterBtnActive: {
    backgroundColor: 'var(--accent)',
    color: '#0a0f13',
    fontWeight: 700,
  },
  sortSelect: {
    backgroundColor: 'var(--panel2)',
    color: 'var(--text)',
    borderWidth: '1px',
    borderStyle: 'solid',
    borderColor: 'var(--border)',
    borderRadius: '10px',
    padding: '7px 12px',
    fontFamily: 'var(--font-fa)',
    fontSize: '12.5px',
    fontWeight: 600,
    outline: 'none',
    cursor: 'pointer',
  },
  addComicBtn: {
    backgroundColor: 'rgba(34, 211, 238, 0.12)',
    borderWidth: '1px',
    borderStyle: 'solid',
    borderColor: 'var(--accent)',
    color: 'var(--accent)',
    padding: '7px 14px',
    borderRadius: '10px',
    fontFamily: 'var(--font-fa)',
    fontSize: '12.5px',
    fontWeight: 700,
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
  },
  foldersBarWrap: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
  },
  foldersScrollRow: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    flexWrap: 'wrap',
  },
  folderTabBtn: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '7px',
    padding: '7px 13px',
    borderRadius: '11px',
    borderWidth: '1px',
    borderStyle: 'solid',
    fontFamily: 'var(--font-fa)',
    fontSize: '12px',
    fontWeight: 600,
    cursor: 'pointer',
    transition: 'all 0.18s ease',
    outline: 'none',
  },
  folderTabCount: {
    fontFamily: 'var(--font-mono)',
    fontSize: '10.5px',
    fontWeight: 700,
    backgroundColor: 'rgba(0, 0, 0, 0.28)',
    padding: '1px 6px',
    borderRadius: '7px',
    direction: 'ltr',
  },
  newFolderBtn: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '6px',
    padding: '7px 13px',
    borderRadius: '11px',
    borderWidth: '1px',
    borderStyle: 'dashed',
    borderColor: 'var(--accent)',
    backgroundColor: 'rgba(34, 211, 238, 0.06)',
    color: 'var(--accent)',
    fontFamily: 'var(--font-fa)',
    fontSize: '12px',
    fontWeight: 700,
    cursor: 'pointer',
    outline: 'none',
  },
  activeFolderActionsBar: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
    gap: '8px',
    padding: '8px 14px',
    borderRadius: '12px',
    backgroundColor: 'var(--panel2)',
    borderWidth: '1px',
    borderStyle: 'solid',
    borderColor: 'var(--border)',
  },
  activeFolderTitle: {
    fontFamily: 'var(--font-fa)',
    fontSize: '12.5px',
    color: 'var(--text)',
  },
  dragToFolderHint: {
    fontFamily: 'var(--font-fa)',
    fontSize: '11px',
    color: 'var(--muted)',
  },
  folderManageBtn: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '5px',
    padding: '5px 10px',
    borderRadius: '8px',
    borderWidth: '1px',
    borderStyle: 'solid',
    borderColor: 'var(--border)',
    backgroundColor: 'var(--panel)',
    color: 'var(--text)',
    fontFamily: 'var(--font-fa)',
    fontSize: '11.5px',
    fontWeight: 600,
    cursor: 'pointer',
  },
  folderEditorCard: {
    padding: '10px 14px',
    borderRadius: '12px',
    backgroundColor: 'rgba(34, 211, 238, 0.08)',
    borderWidth: '1px',
    borderStyle: 'solid',
    borderColor: 'var(--accent)',
  },
  folderEditorRow: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
    flexWrap: 'wrap',
    color: 'var(--accent)',
  },
  folderNameInput: {
    flex: 1,
    minWidth: '210px',
    backgroundColor: 'var(--panel)',
    borderWidth: '1px',
    borderStyle: 'solid',
    borderColor: 'var(--border)',
    borderRadius: '9px',
    padding: '7px 12px',
    color: 'var(--text)',
    fontFamily: 'var(--font-fa)',
    fontSize: '12.5px',
    outline: 'none',
    userSelect: 'text',
  },
  folderColorPicker: {
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
  },
  folderColorDot: {
    width: '18px',
    height: '18px',
    borderRadius: '50%',
    borderWidth: '2px',
    borderStyle: 'solid',
    cursor: 'pointer',
    padding: 0,
    transition: 'transform 0.15s ease',
  },
  folderSaveBtn: {
    backgroundColor: 'var(--accent)',
    color: '#0a0f13',
    border: 'none',
    borderRadius: '9px',
    padding: '7px 14px',
    fontFamily: 'var(--font-fa)',
    fontSize: '12px',
    fontWeight: 700,
    cursor: 'pointer',
  },
  folderCancelBtn: {
    backgroundColor: 'var(--panel)',
    color: 'var(--muted)',
    borderWidth: '1px',
    borderStyle: 'solid',
    borderColor: 'var(--border)',
    borderRadius: '9px',
    padding: '7px 12px',
    fontFamily: 'var(--font-fa)',
    fontSize: '12px',
    cursor: 'pointer',
  },
  cardsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(175px, 1fr))',
    gap: '16px',
  },
  // مرحله ۴ — اسکلتِ کارتِ خارج از دید: همان ساختارِ کارت (کاورِ ۳:۴ +
  // دو خطِ متن) تا ارتفاعِ گرید هنگامِ مانتِ واقعی تقریباً تکان نخورد.
  cardSkeleton: {
    backgroundColor: 'var(--panel)',
    borderRadius: '16px',
    padding: '10px',
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    borderWidth: '1px',
    borderStyle: 'solid',
    borderColor: 'var(--border)',
  },
  skeletonCover: {
    width: '100%',
    aspectRatio: '3 / 4',
    borderRadius: '12px',
    backgroundColor: 'var(--panel2)',
  },
  skeletonLine: {
    height: '13px',
    borderRadius: '6px',
    backgroundColor: 'var(--panel2)',
  },
  emptyBox: {
    padding: '48px 20px',
    textAlign: 'center',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '8px',
  },
  emptyText: {
    fontFamily: 'var(--font-fa)',
    fontSize: '13.5px',
    fontWeight: 600,
    color: 'var(--muted)',
  },
};